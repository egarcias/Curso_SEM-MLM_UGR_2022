#--------------------------------------------------------------------------------#
#
# Curso "Principios y Pr?cticas de Ecuaciones Estructurales y An?lisis Multinivel 2a ed. (2022)
# Sesi?n 2: Modelos de regresi?n lineal
# Escrito por: Efra?n Garcia-Sanchez. 
# e-mail: egarcias@correo.ugr.es or egarsa@gmail.com
# Por favor contactarme si encuentra alg?n error o tiene alguna pregunta
# Fecha: 21/04/2021
# 
#--------------------------------------------------------------------------------#

#### 0. Preparar el ambiente de trabajo ####

install.packages("pacman")

library(pacman)

p_load(tidyverse, car, sjPlot)

getwd()

#### 1. Exploraci?n inicial de datos ####

#### 1. Cargar datos ####

data1 <- read_csv("data/data_1_2_redist_brasil.csv") # NOTA: tener en cuenta la ubicaci?n del archivo
data1 <- rio::import("data/data_1_2_redist_brasil.csv") # NOTA: tener en cuenta la ubicaci?n del archivo

glimpse(data1)


#### 1.1 Manipulaci?n de datos ####

# Funciones b?sicas

# select()    = Selecciona cierto tipo de columnas/variables
# filter()    = Filtro para seleccionar filas (casos o participantes)
# arrange()   = Ordena u organiza los casos 
# mutate()    = Crea nuevas columnas o variables 
# summarize() = Resumen de datos
# group_by()  = Realiza operaciones por grupos espec?ficos 


# para seleccionar un conjunto de variables (subset)
data1 %>% 
  select(quest, onda, area_chave)

# para identificar cierto tipo de personas
data1 %>% 
  filter(quest < 10)

# para ordenar personas seg?n informaci?n
data1 %>% 
  select(quest, onda, area_chave, idade) %>% 
  filter(quest < 10) %>% 
  arrange(idade)

# para crear variables
data2 <- data1 %>% 
  mutate(variable1 = (CPconc_prosp + CPprob_quali)/2) %>% 
  select(quest, variable1)


# para resumir en general
data1 %>% 
  mutate(variable1 = (CPconc_prosp + CPprob_quali)/2) %>% 
  summarize(mean_var = mean(variable1),
            sd_var = sd(variable1))

# para resumir en general
data1 %>% 
  group_by(area_chave) %>% 
  mutate(variable1 = (CPconc_prosp + CPprob_quali)/2) %>% 
  summarize(mean_var = mean(variable1),
            sd_var = sd(variable1),
            total = n()) %>% 
  ungroup()

# otra forma

data1 %>% 
  mutate(variable1 = (CPconc_prosp + CPprob_quali)/2) %>% 
  sjmisc::descr(variable1)


data1 %>% 
  mutate(variable1 = (CPconc_prosp + CPprob_quali)/2) %>% 
  sjmisc::descr()


#### 1.2 Preparaci?n de datos ####
install.packages("sjmisc")

library(sjmisc)

?descr

data1 %>% 
  sjmisc::descr(out = "viewer", encoding = "windows-1252")

data1 <- data1 %>% 
  mutate(
    # Eliminando valores perdidos
    CPconc_prosp = sjmisc::set_na(CPconc_prosp, na = c(6,7,8,9, 99)),  
    CPcontex_desig = sjmisc::set_na(CPcontex_desig, na = c(6,7,8,9, 99)), 
    CPcontex_bf = sjmisc::set_na(CPcontex_bf, na = c(6, 7,8,9, 99)), 
    CPprob_quali = sjmisc::set_na(CPprob_quali, na = c(6, 7,8,9, 99)), 
    SDrendf_fam = sjmisc::set_na(SDrendf_fam, na = c(7,8,9,99)),
    # Recoding values: highher values means higher acceptance/agreement
    CPconc_prospr = (6 - CPconc_prosp),
    CPcontex_desigr = (6 - CPcontex_desig),
    CPcontex_bfr = (6 - CPcontex_bf),
    CPprob_qualir = (6 - CPprob_quali),
    SDrendf_famr = (7 - SDrendf_fam),
    raca_ppi = dplyr::recode(SDraca, '1' = 0L, '2' = 1L, '3'= 1L, '4'= 1L,'5'= 1L,'6'= 1L),
    sexor = dplyr::recode(sexo, '1' = 1L, '2' = 0L)
  )

table(data1$CPconc_prosp)
# s?lo para verificar las transformaciones (rango de datos)

data1 %>% 
  select(CPconc_prosp, CPconc_prospr,
         CPcontex_desig, CPcontex_desigr,
         CPcontex_bf, CPcontex_bfr,
         CPprob_quali, CPprob_qualir,
         SDrendf_fam, SDrendf_famr) %>% 
  descr(out = "viewer")


# Variables de inter?s
# VD = CPcontex_desigr "apoyo a la redistribuci?n"
# VI_1 = SDrendf_famr "Estatus por ingresos familiares"
# VI_2 = CPescala_rend "Estatus subjetivo"
# VI_3 = CPcontex_bfr "creencia redistribuci?n desmotiva el trabajo"
# VC_1 = raca_ppi
# VC_2 = idade
# VC_3 = sexor

#### 1.3 Exploraci?n de datos ####

# Descriptivos
data1 %>% 
  select(CPcontex_desigr, 
         SDrendf_famr, CPescala_rend,
         CPcontex_bfr, 
         raca_ppi, sexor, idade) %>% 
  sjmisc::descr()


data1 %>% 
  select(CPcontex_desigr, 
         SDrendf_famr, CPescala_rend,
         CPcontex_bfr, 
         raca_ppi, sexor, idade) %>% 
  psych::describe()

# correlaciones

# Opci?n 1: SJPLOT
data1 %>% 
  select(CPcontex_desigr, 
         SDrendf_famr, CPescala_rend,
         CPcontex_bfr, 
         raca_ppi, sexor, idade) %>% 
  sjPlot::tab_corr(digits = 3, triangle = "lower")
  
# Opci?n 2: PSYCH
data1 %>% 
  select(CPcontex_desigr, 
         SDrendf_famr, CPescala_rend,
         CPcontex_bfr, 
         raca_ppi, sexor, idade) %>% 
  psych::pairs.panels()

#opci?n 3: GGALLY

data1 %>% 
  select(CPcontex_desigr, 
         SDrendf_famr, CPescala_rend,
         CPcontex_bfr, 
         raca_ppi, sexor, idade) %>% 
  GGally::ggpairs()

# otras opciones

hist(data1$CPcontex_desigr)

boxplot(data1$CPcontex_desigr)

plot(data1$CPcontex_desigr, data1$SDrendf_famr)
abline(lm(data1$CPcontex_desigr ~ data1$SDrendf_famr), col = "red")


# con ggplot
ggplot(data1, aes(x = SDrendf_famr, y = CPcontex_desigr)) +
  geom_point() +
  geom_jitter() +
  geom_smooth(method = "lm", se = TRUE) +
  theme_bw()

ggplot(data1, aes(x = "", y = CPcontex_desigr)) +
  geom_point() +
  geom_jitter() +
  geom_boxplot() +
  theme_bw()


# Mahalanobis distance
library(rstatix)

data1 %>% 
  select(CPcontex_desigr, 
         SDrendf_famr, CPescala_rend,
         CPcontex_bfr, 
         raca_ppi, sexor, idade) %>% 
  na.omit() %>%  # para remover valores perdidos
  mahalanobis_distance() %>% 
  filter(is.outlier == TRUE) 
  

data1 <- data1 %>% 
  select(CPcontex_desigr, 
         SDrendf_famr, CPescala_rend,
         CPcontex_bfr, 
         raca_ppi, sexor, idade) %>% 
  na.omit() %>%  # para remover valores perdidos
  mahalanobis_distance() %>% 
  filter(!is.outlier == TRUE)  # para eliminar los casos que sean outliers


names(data1)


#### 2. An?lisis: Regresi?n Lineal ####

# el intercepto

m0 <- lm(CPcontex_desigr ~ 1, data = data1)

summary(m0)

# igual a la media de la variable
psych::describe(data1$CPcontex_desigr)

# Regresi?n simple (un solo predictor)
m1 <- lm(CPcontex_desigr ~ SDrendf_famr, 
         data = data1)

summary(m1)

# igual a la correlaci?n entre las dos variables

cor.test(data1$CPcontex_desigr, data1$SDrendf_famr)

# Cuando adicionamos otras variables, el efecto cambia

m2 <- lm(formula = CPcontex_desigr ~ SDrendf_famr + CPescala_rend, 
                     data = data1)

m3 <- lm(CPcontex_desigr ~ SDrendf_famr + CPescala_rend +
                    raca_ppi +  sexor + idade, 
                    data = data1)

# par?metros simples 
print(m2)

# con el test de significancia
summary(m2)

# int?rvalos de confianza
confint(m2)


# Reportar varios modelos

sjPlot::tab_model(m0, m1, m2, m3)

# betas estandarizados

# opci?n 1 REGHELPER
install.packages("reghelper")
library(reghelper)

reghelper::beta(m2)

summary(m2)

# Opci?n 2 SJPLOT

sjPlot::tab_model(m0, m1, m2, m3, 
                  show.std = TRUE)


# otra opci?n 3: estandarizar las variables antes de hacer el an?lisis

m2_beta <- lm(formula = scale(CPcontex_desigr) ~ scale(SDrendf_famr) + scale(CPescala_rend), 
         data = data1)

summary(m2_beta)

#### Revisando los supuestos del modelo ####

# Linealidad de las relaciones 

plot(x = m3, which = 1)


# homogeneidad de varianza

plot(x = m3, which = 3)

# Colinealidad: VIF
car::vif(m3)


# Otras opciones
install.packages("performance")
library(performance)

check_model(m3)

# comparar modelos
AIC(m2, m3)

anova(m1, m2, m3)

# tal vez otro tipo de modelo
install.packages("MASS")
library(MASS)

m4 <- polr(as.factor(CPcontex_desigr) ~ SDrendf_famr + CPescala_rend +
              raca_ppi +  sexor + idade, 
            data = data1)

summary(m4)

summary(m3)

# Reportar los modelos de forma textual y en tablas

library(report)

report::report(m3)

report::report_table(m3)

?report

# Reportar los modelos de forma gr?fica

sjPlot::plot_model(m3)

sjPlot::plot_model(m3,
                   type = "std",
                   show.values = TRUE,
                   show.p = TRUE) 

sjPlot::plot_model(m3,
                   type = "std",
                   show.values = TRUE,
                   show.p = TRUE) +
  theme_bw() +
  geom_hline(yintercept = 0, 
             linetype = 2, 
             color = "gray50")

# otras opciones 
install.packages("coefplot")
library(coefplot)

coefplot(m3)

coefplot(m3,
         intercept = FALSE, 
         sort = "magnitude")

#--------------------------------------------------------------------------------------------#
# EJERCICIOS 
#--------------------------------------------------------------------------------------------#

# 1. Explorar y describir los datos usados en el texto de Hayes sobre calentamiento global (glbwarm) (p. 31, Hayes, 2022)

# importar los datos
glbwarm <- rio::import("data/glbwarm.csv")

glimpse(glbwarm) # tiene 7 columnas y 815 casos

psych::describe(glbwarm)

sjmisc::descr(glbwarm, out = "viewer")

# 2. Revisar las correlaciones entre el apoyo a que el gobierno actúe para reducir el cambio climático (govact) y las dem?s variables

sjPlot::tab_corr(glbwarm, 
                 triangle = "lower" # este argumento para dejar sólo los coeficientes bajo la diagonal
                 )

# 3. Realizar un an?lisis de regresi?n lineal m?ltiple: VD = govact, VI = posemot, negemot, ideology, age, sex

mod_lineal <- lm(govact ~ posemot + negemot + ideology +  sex + age, 
                 data = glbwarm) 

summary(mod_lineal)

# 4. Reportar los resultados de la regresi?n lineal (e.g., texto, tablas, figuras, etc.)

# un ejemplo para reportarlo en formato texto
report::report(mod_lineal)

# un ejemplo usando tablas
sjPlot::tab_model(mod_lineal)

# un ejemplo usando figuras
sjPlot::plot_model(mod_lineal)

coefplot::coefplot(mod_lineal)
