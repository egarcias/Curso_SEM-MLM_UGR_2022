#--------------------------------------------------------------------------------#
#
# Curso "Principios y Pr?cticas de Ecuaciones Estructurales y Análisis Multinivel 2a ed. (2022)
# Sesi?n 1: Modelamiento e introducción a R
# Escrito por: Efrain Garcia-Sanchez. 
# e-mail: egarcias@correo.ugr.es or egarsa@gmail.com
# Fecha: 21/04/2021
# 
#--------------------------------------------------------------------------------#

# Estos ejercicios basados usando dos textos de referencia:
# https://learningstatisticswithr.com/book/mechanics.html
# https://r4ds.had.co.nz/explore-intro.html

#--------------------------------------------------------------------------------#
#### 1.1 Operaciones bÃ¡sicas ####
#--------------------------------------------------------------------------------#

# C?lculos simples
10 + 30

# Tener cuidado con los errores

10 = 30

10 - 20

# el espacio no suele importar mucho

10+20

10+   20 

10     +20

# para citar
citation()

citation("psych")

citation () 

citat ion () # no lo acepta

# cosas pendientes por terminar 
10 + 
  
    20

# Operaciones bÃ¡sicas

10 + 20 # Suma
10 - 20 # resta
10 * 20 # multiplicación
10 / 20 # división
10 ^ 2 # potenciación

# Orden de las fórmulas

1 + 2 * 4

(1 + 2) * 4

(4 / 2) * 3

# Guardar objetos

variable_1 <- 350

variable_1 = 350

variable_1

350 -> variable_1a # pero no es común

variable_2 = 350

# Usar funciones

sqrt(225) # raíz cuadrada

27^(1/3) # raíz cúbica (Nota: notación álgebra)

abs( -13 ) # Número absoluto

sqrt( 1 + abs(-8) )

# vector (Conjunto de elementos)
variable_3 <- c(1,2,3,4,5,6,7,8,9)

variable_3

# funciones disponibles

mean(variable_3)

sd(variable_3)

round( 3.1415165896521545 )

round( x = 3.1415165896521545, digits = 2 )

round( 3.1415, 2 )


# consultar sobre la función
?round

# Auto-completar funciones (doble tab)

round(x = 2.36525698, digits = 3)

round(x = ,digits = )

?round()

# vectores 

variable_3 * 2

length(variable_3)

# Operadores lógicos


  <   #less than	            <	2 < 3       TRUE
  <=  #less than or equal to	<=	2 <= 2	  TRUE
  >   #greater than	>	        2 > 3         FALSE
  >=  #greater than or equal to	>=	2 >= 2	TRUE
  ==  #equal to	==	          2 == 3        FALSE
  !=  #not equal to	!=	      2 != 3        TRUE
  
100 < 90

100 <= 99

100 >= 99

100 == 10^2

# otros operadores boleanos

  ! # NOT
  | # OR
  & # AND  
  

#--------------------------------------------------------------------------------#
#### 1.2 Otras operaciones y objetos de utilidad ####
#--------------------------------------------------------------------------------#

# comentarios

seeker <- 3.1415           # Crea la primera variable
lover <- 2.7183            # Crea la segunda vaiable
keeper <- seeker * lover   # multiplica las variables para crear una tercera
print( keeper )            # muestra en la consola el valor de la variable

#--------------------------------------------------------------------------------#
#### 1.3 Instalar, cargar y usar paquetes ####
#--------------------------------------------------------------------------------#

# NOTA: Los paquetes como aplicaciones (conjuntos de funciones para realizar operaciones)

# Instalar y cargar paquetes

exists( "read.spss" ) # esta funcion no está  cargada

exists( "mean" ) # si la función está cargada

# Para instalar
install.packages("foreign") # Nota: tener cuidado, instala la última versión del paquete

# Para cargar
library(foreign)

exists( "read.spss" ) # ahora esta  cargada en nuestro ambiente

# cargar varios paquetes manualmente


# usar una función para cargar paquetes
install.packages("pacman")
library(pacman)

p_load(tidyverse, foreign, car)

# NOTA: 
# Instalar el paquete para poder cargaralo
# Cargar el paquete para poder usarlo

# NOTA: El panel de los paquetes (PACKAGE PANEL)

# Desactivar el paquete

detach("package:foreign", unload=TRUE)

# desactivar en el panel de los paquetes

# Algunas funciones usan el mismo nombre en diferentes paquetes
library(car)
library(psych)

psych::logit()

car::logit()


?logit

# Algunos paquetes importantes para el seminario

tidyverse   # conjunto de paquetes para manipulación y visualización de datos
psych       # Análisis de datos en psicologÃÂ­a
lavaan      # Análisis de ecuaciones estructurales
sem 
sjPlot      # visualizacion y reportes de información
GGally      # Visualización y reporte de información
car         # Companion to applied regression package


# Examinar el ambiente de trabajo

objects()

# Eliminar elementos del ambiente de trabajo
# NOTA: No hay forma de "deshacer" cuando algo se elimina
# Solución: se vuelve a ejecutar el código hasta el último paso

rm(keeper, lover)

# borrar todo el ambiente de trabajo
rm(list = ls())

# Botón Clear (cepillo en el panel del Global environment)

# limpiar la consola

Ctrl + l

#--------------------------------------------------------------------------------#
#### 1.4 preparar la sesión de trabajo ####
#--------------------------------------------------------------------------------#

# Opción 1: código

getwd() # directorio de trabajo

setwd("C:/Users/Usuario/Dropbox/Cursos (docencia)/Curso SEM Multinivel UGR 2021/2a_ed_2022/R_code")

setwd()

# Opción 2. Manual

# Session --> set workind directory --> choose directory

# Opci?n 3. comando

# Ctrl + Shift + h

# podemos examinar los archivos que hay en ese directorio

list.files()

list.files("R_code")


# encoding

getOption("encoding")

# File --> save with encoding --> UTF-8


#--------------------------------------------------------------------------------#
#### 1.5 Cargar los datos  ####
#--------------------------------------------------------------------------------#

load(file = "path")

# Cargar el ambiente de trabajo

load("")

load(file = "C:/Users/Usuario/Dropbox/Cursos (docencia)/Curso SEM Multinivel UGR 2021/2a_ed_2022/R_code/Sesion_1_1_env.RData")

load("C:/Users/Usuario/Dropbox/Cursos (docencia)/Curso SEM Multinivel UGR 2021/2a_ed_2022/R_code/Sesion_1_1_env.RData")

# Guardar el ambiente de trabajo

save.image("Sesion_1_1_env.RData")

#--------------------------------------------------------------------------------#
#### 1.6 Objetos en R ####
#--------------------------------------------------------------------------------#


# vectores: conjuntos de elementos
# matrices: de doble entrada
# list: conjunto de vectores (distinto tamaÃ±o)
# data.frame / tibbles: conjunto de vectores (mismo tamaÃ±o)


# objetos pueden ser de distintos tipos

# numericos (doubles, integer)
# caracteres: texto
# logicals

#### 1.7 Crear/cargar datos ####

# opción 1, crear vectores y luego unirlos

month = c("January","February","March","April","May","June","July",
          "August","September","October","November","December") 

days = c(31,28,31,30,31,30,31,31,30,31,30,31)

sales = c(0,100,200,50,0,0,0,0,0,0,0,0)

stock = c("high","high","low","out","out","high","high","high",
          "high","high","high","high")

# combinar vectores en una matrix

data0 <- cbind(month, days, sales, stock)

class(data0)

data0 <- as.data.frame(data0)

class(data0)

data0

View(data0)

# convertirla la matrix en una base de datos (data.frame)

data0 <- as.data.frame(data0)

class(data0)

data0

# crear una base de datos (tibbles)

library(tidyverse)

data1 <- tibble(
  month = c("January","February","March","April","May","June","July","August","September","October","November","December"), 
  days = c(31,28,31,30,31,30,31,31,30,31,30,31), 
  sales = c(0,100,200,50,0,0,0,0,0,0,0,0),
  stock = c("high","high","low","out","out","high","high","high","high","high","high","high")
  )

data1

names(data1)

# vamos a guardar este archivo en formato csv
write.csv()

write_csv(data1, file = "data/data_1_1_ejemplo.csv")

getwd()

# vamos a cargar estar archivo al ambiente de trabajo


data2a <- readr::read_csv("data/data_1_1_ejemplo.csv")

data2b <- rio::import("data/data_1_1_ejemplo.csv")


# exploraciones iniciales

dim(data2)

length(data2)

glimpse(data2)

head(data2)

tail(data2)

class(data2)

is.data.frame(data2)

is.matrix(data2)
 
#--------------------------------------------------------------------------------#
#### 1.7 Algunos ejercicios ####
#--------------------------------------------------------------------------------#

# 1.7.1 Crear un vector numérico de 10 elementos

vector1 <- c(1,2,3,4,5,6,7,8,9,10)

vector1

# 1.7.2 Crear un vector de texto de 10 elementos

vector2 <- c("a","b","c","d","e","f","g","h","j","k") # NOTA: tener en cuenta que los datos de texto deben estar indicados entre comillas

vector2

# 1.7.3 Unir los dos vectores en una base de datos (data.frame)

data_ejercicio <- as.data.frame(cbind(vector1, vector2)) # primero fusiono los vectors, luego lo convierto en una base de datos

# 1.7.4 Cargar un conjunto de datos (intentar varias opciones)

data_ejemplo <- rio::import("data/data_1_1_ejemplo.csv")

data_ejemplo <- readr::read_csv("data/data_1_1_ejemplo.csv") # NOTA: tener en cuenta la terminación del archivo

# 1.7.5 Explorar las características del conjunto de datos

library(tidyverse) # conjunto de paquetes para exploración de datos

glimpse(data_ejemplo) # informe del tipo de variables resumido

head(data_ejemplo) # primeras filas

tail(data_ejemplo) # últimas filas

str(data_ejemplo) #Estructura de la base de datos

# 1.7.6 Guardar el ambiente de trabajo y exportar los datos en formato CSV

save.image("environment/ejercicio.Rdata")



#### Sesión ####

sessionInfo()

save.image("Sesion_1_1_env.RData")

