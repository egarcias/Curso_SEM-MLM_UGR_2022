#--------------------------------------------------------------------------------#
#
# Curso "Principios y Pr�cticas de Ecuaciones Estructurales y An�lisis Multinivel 2a ed. (2022)
# Sesi�n 3: An�lisis de moderaci�n
# Escrito por: Efra�n Garcia-Sanchez. 
# e-mail: egarcias@correo.ugr.es or egarsa@gmail.com
# Por favor contactarme si encuentra algún error o tiene alguna pregunta
# Fecha: 21/04/2022
# 
#--------------------------------------------------------------------------------#

#### 0. Preparar el ambiente de trabajo ####

library(pacman)

p_load(tidyverse, # conjunto de paquetes para manipulaci�n y visualizaci�n de datos
       car, # para modelos de regresi�n 
       sjPlot, # para visualizaci�n de resultados
       sjmisc, # funciones para manipulaci�n de datos
       reghelper, # funciones para análisis de regresi�n
       interactions, # funciones para analizar moderaciones
       interplot, # probing interactions - efectos marginales
       GGally # para visualizaci�n y reporte de informaci�n
       )

getwd()


#### 1. Exploraci�n inicial de datos ####

#### 1.1 Cargar datos ####
library(haven) # para cargar datos de SPSS

data <- haven::read_sav("data/data_1_3_video_games.sav") # NOTA: tener en cuenta la ubicaci�n del archivo

data <- rio::import("data/data_1_3_video_games.sav") # NOTA: tener en cuenta la ubicaci�n del archivo

glimpse(data)

#### 1.2 Exploraci�n de los datos ####

# distribuci�n de los datos y correlaciones
data %>% 
  dplyr::select(-ID) %>% 
  ggpairs()

# otra opci�n

psych::pairs.panels(data[  ,c(2:4)])

#### 1.2.1 estad�sticos descriptivos ####

# opci�n 1
data %>% 
  dplyr::select(-ID) %>% 
  descr(show = "short")

# opci�n 2
data %>% 
  dplyr::select(-ID) %>% 
  sjmisc::descr(out = "viewer")

# opci�n 3
data %>% 
  dplyr::select(-ID) %>% 
  psych::describe()

#### 2. Manipulaci�n y transformaci�n de los datos ####

# Centrando las variables

# opci�n 1
data$CaUnTs_cen1 = as.vector(scale(data$CaUnTs, center = TRUE, scale = FALSE))
data$Vid_Game_cen1 = as.vector(scale(data$Vid_Game, center = TRUE, scale = FALSE))

names(data)

# opci�n 2 (Tidyverse)
data <- data %>% 
  mutate(CaUnTs_cen2 = sjmisc::center(CaUnTs),
         Vid_Game_cen2 = sjmisc::center(Vid_Game)
         )


glimpse(data)

# ver data
data

# nombres 
names(data)

# verificar para el caso 1

16 - (mean(data$Vid_Game))

#### 3. Calcular el modelo ####

m0 <- lm(Aggress ~ 1, data = data)

m1 <- lm(Aggress ~ Vid_Game + CaUnTs, data = data)

m2 <- lm(Aggress ~ Vid_Game_cen1 + CaUnTs_cen1, data = data)

# ver los modelos 
tab_model(m0, m1, m2)

# Notar que no cambian los efectos, pero s� el intercepto. Recordar la interpretaci�n

# Crear la interacci�n

# m1 <- lm(Aggress ~ Vid_Game + CaUnTs, data = data)

m1a <- lm(Aggress ~ Vid_Game + CaUnTs + Vid_Game*CaUnTs, data = data)

m2a <- lm(Aggress ~ Vid_Game_cen2 + CaUnTs_cen2 + Vid_Game_cen2*CaUnTs_cen2, data = data)

print(m1)
summary(m1a)
confint(m1a)

# otra opci�n
tab_model(m1a, m2a)

# si los vemos todos al mismo tiempo

tab_model(m1, m1a, m2, m2a)

# si comparo los modelos con y sin interacci�n, puedo rechazar la hip�tesis nula de quel los modelos son iguales
anova(m1, m1a)

# Tambi�n el AIC es menor, por lo que puede decirse que el modelo con la interacci�n es mejor (no se suele hacer)
AIC(m1, m1a)

# verificar el modelo 

performance::check_model(m1)

car::vif(m1)

#### 4. Simple slopes analyses ####

library(interactions)

probe_interaction(model = m2a, 
                  pred = "Vid_Game_cen2", 
                  modx = "CaUnTs_cen2")

?probe_interaction


# Simple slopes tests (INTERACTIONS)
interactions::sim_slopes(model = m2a, pred = "Vid_Game_cen2", modx = "CaUnTs_cen2", digits = 3)

# simple slopes (REGHELPER)

reghelper::simple_slopes(m2a)


#### 5.2 Visualization: simple slopes analyses ####
interact_plot(model = m2a, pred = "Vid_Game_cen2", modx = "CaUnTs_cen2", 
              interval = TRUE, 
              plot.points = TRUE) +
  theme_bw()

# Video Juegos como moderador

# Simple slopes tests (video juegos como moderador)
sim_slopes(model = m2a, pred = "CaUnTs_cen2", modx = "Vid_Game_cen2", digits = 3)

interact_plot(model = m2a, pred = "CaUnTs_cen2", modx = "Vid_Game_cen2", 
              interval = TRUE, 
              plot.points = TRUE) +
  theme_bw() +
  labs(x = "Insensibilidad")


#### 5.2 Visualization: jhonson newman plot ####
interact_plot(model = m2a, pred = "Vid_Game_cen2", modx = "CaUnTs_cen2", 
              linearity.check = TRUE)

interact_plot(model = m2a, pred = "Vid_Game_cen2", modx = "CaUnTs_cen2", facet.modx = TRUE)

interactions::johnson_neyman(m2a, pred = "Vid_Game_cen2", modx = "CaUnTs_cen2")


#### 5.3 Visualization: efectos marginales (interplot) ####

library(interplot)

interplot(m = m2a, var1 = "Vid_Game_cen2", var2 = "CaUnTs_cen2")

# con algunas adiciones
interplot(m = m2a, var1 = "Vid_Game_cen2", var2 = "CaUnTs_cen2") +
  xlab("Insensibilidad emocional") +
  ylab("Coeficiente estimado del \nconsumo de videojuegos") +
  # Change the background
  theme_bw() +
  # Add the title
  ggtitle("Coeficiente estimado del consumo de videojuegos \nsobre la agresividad por la insensibilidad") +
  theme(plot.title = element_text(face="bold")) +
  # Add a horizontal line at y = 0
  geom_hline(yintercept = 0, linetype = "dashed")


#### 5.4 usando process (Hayes, 2022, p. 579 )
#cargar process

process(
  data = data,
  y = "Aggress",
  x = "Vid_Game",
  w = "CaUnTs",
  model = 1, # Modelo que se va a estimar
  center = 2, # mean center all the variables; 2 if only the predictor and moderator should be centered
  jn = 1,
  plot = 1, 
  decimals = 9.3, # para tres decimales
  modelbt = 1, # para tener bootstrapped CI
  boot=5000 
)

#### Ejercicios #####

# 1. Cargar los datos de Disaster de (hayes2022data) (p. 245, Hayes, 2022)

disaster <- rio::import("data/disaster.csv")

# 2. Explorar los datos de Disaster

glimpse(disaster)

psych::describe(disaster)

GGally::ggpairs(disaster)

# 3. Evaluar la moderaci�n entre frame y skeptic, sobre justify (usar cualquier m�todo para hacerlo)

moderacion1 <- lm(justify ~ frame*skeptic, 
                  data = disaster)


summary(moderacion1)

# 4. Probar (Probing) la moderaci�n (simple slopes y regiones de significancia)
interactions::sim_slopes(
  model = moderacion1,
  pred = "skeptic",
  modx = "frame"
  )


#simple slopes
interactions::interact_plot(
  model = moderacion1,
  pred = "skeptic",
  modx = "frame",
  centered = TRUE,
  interval = TRUE,
  plot.points = TRUE
  )


interactions::interact_plot(
  model = moderacion1,
  pred = "frame",
  modx = "skeptic",
  centered = TRUE,
  interval = TRUE,
  plot.points = TRUE
)

# regiones de significancia

interactions::johnson_neyman(
  model = moderacion1,
  pred = "skeptic",
  modx = "frame"
  )


interplot::interplot(
  m = moderacion1,
  var1 = "frame",
  var2 = "skeptic",
  ci = TRUE,
  hist = TRUE
  ) +
  labs(title = "Efecto marginal del escepticismo sobre la justificaci�n de los desastres naturales \ncondicionado por el encuadre",
       x = "Escepticismo",
       y = "Efecto marginal del encuadre")
  

# 5. Interpretar los resultados (�qu� quiere decir?)

# De acuerdo con los resultados del modelo, podemos decir que hay una interacci�n entre el encuadre de las noticias (frame) y 
# el escepticismo de las personas sobre la disposici�n a justificar los desastres naturales (b = .20, SE = .05, t = 3.64, p < .001, 95% CI [0.09, 0.31]).
# El an�lisis de pendientes simples muestra que el efecto positivo del escepticismo sobre la justificaci�n de los desastres es mayor 
# cuando el encuadre del desastres se presenta relacionado con actividades humanas (b = .031, SE = .04, t = 7.65, p <.001) que cuando 
# se encuadran los desastres en t�rminos de causas naturales (b = .011, SE = .04, t 2.76, p = .01).