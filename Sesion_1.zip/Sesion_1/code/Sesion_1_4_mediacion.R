#--------------------------------------------------------------------------------#
#
# Curso "Principios y Pr�cticas de Ecuaciones Estructurales y An�lisis Multinivel 2a ed. (2022)
# Sesi�n 4: An�lisis de mediaci�n
# Escrito por: Efra�n Garcia-Sanchez. 
# e-mail: egarcias@correo.ugr.es or egarsa@gmail.com
# Por favor contactarme si encuentra alg�n error o tiene alguna pregunta
# Fecha: 21/04/2022
# 
#--------------------------------------------------------------------------------#

#--------------------------------------------------------------------------------#
#### 0. Preparar el ambiente de trabajo ####
#--------------------------------------------------------------------------------#

library(pacman)

p_load(tidyverse, # conjunto de paquetes para manipulaci�n y visualizaci�n de datos
       car, # para modelos de regresi�n 
       sjPlot, # para visualizaci�n de resultados
       sjmisc, # funciones para manipulaci�n de datos
       GGally, # para visualizaci�n y reporte de informaci�n
       psych, # funciones para an�lisis de datos en psicolog�a
       lavaan # para realizar an�lisis de caminos y SEM
       )


getwd()

#--------------------------------------------------------------------------------#
#### 1. Exploraci�n inicial de datos ####
#--------------------------------------------------------------------------------#

#### 1.1 Cargar datos ####
library(haven) # para cargar datos de SPSS

data <- haven::read_sav("data/data_1_4_Lambert_2012.sav") # NOTA: tener en cuenta la ubicaci�n del archivo

class(data)

glimpse(data)

data

#--------------------------------------------------------------------------------#
#### 1.2 exploraci�n de los datos ####
#--------------------------------------------------------------------------------#

data %>% 
  dplyr::select(Commit, LnPorn, Phys_Inf) %>% 
  ggpairs()


data %>% 
  dplyr::select(Commit, LnPorn, Phys_Inf) %>% 
  psych::pairs.panels()

# Estad�sticos descriptivos

data %>% 
  dplyr::select(Commit, LnPorn, Phys_Inf) %>% 
  psych::describe()

#--------------------------------------------------------------------------------#
#### 2. An�lisis de Mediaci�n ####
#--------------------------------------------------------------------------------#

#### 2.1 Mediaci�n simple ####

# funci�n mediate del paquete psych
?mediate

m1 <- psych::mediate(Phys_Inf ~ LnPorn + (Commit), 
        data = data, 
        n.iter = 100, # aumentar a 5000 
        alpha = 0.05, # 95% CI 
        std = FALSE,
        plot=TRUE,
        main="An�lisis de Mediaci�n (LnPorn -> Commmit -> Phys_inf")

summary(m1, digits = 3)

# Process (Modelo 4)

process(
  data = data,
  y = "Phys_Inf",
  x = "LnPorn",
  m = "Commit",
  model = 4, # Modelo que se va a estimar
  decimals = 9.3, # para tres decimales
  modelbt = 1, # para tener bootstrapped CI
  boot=5000 
)

# Lavaan
library(lavaan)

m1a <- 'Commit   ~ a*LnPorn # comentario 1
        Phys_Inf ~ c*LnPorn + b*Commit  # comentario 2
        
        # Indirect effects
        ind1  := a*b
        total := c + (a*b)
        
        # Effect size
        ratio1 := (a*b)/total
        ratio2 := (a*b)/c
        '

m1a_fit <- sem(m1a, data = data)

summary(m1a_fit, 
        ci = TRUE, 
        rsquare =TRUE,
        standardized = TRUE)


# bootstrap
m1a_fit <- sem(m1a, data =data, 
               se = "bootstrap", 
               bootstrap = 100) # lo ideal es hacerlo con > 5000 bootstraps

summary(m1a_fit, 
        ci = TRUE, 
        standardized = TRUE)

# Ver los resultados
tabl1 <- parameterestimates(m1a_fit, 
                   boot.ci.type = "perc") %>% 
  knitr::kable()

parameterestimates(m1a_fit, 
                   boot.ci.type = "bca.simple") %>% 
  knitr::kable()


# Visualizar la mediaci�n de un objeto LAVAAN (SEMPLOT)

library(semPlot)

semPlot::semPaths(m1a_fit, "std", edge.label.cex = 0.5, curvePivot = TRUE)

semPaths(m1a_fit, layout = "tree2")

semPaths(m1a_fit, layout = "spring", "std")

semPaths(m1a_fit, whatLabels = "std")

# lavaan plot: un paquete nuevo, pero a�n est� en prueba
install.packages("lavaanPlot")
library(lavaanPlot)

lavaanPlot(
  model = m1a_fit,
  node_options = list(shape = "box", fontname = "Helvetica"),
  edge_options = list(color = "grey"),
  coefs = TRUE
  )

labels <- list(LnPorn = "Porn consumption", Commit = "Relationship commitment", Phys_Inf = "Infidelity")

lavaanPlot(
  model = m1a_fit,
  labels = labels,
  node_options = list(shape = "box", fontname = "Helvetica"),
  edge_options = list(color = "grey"),
  coefs = TRUE
)


# tidy SEM https://cjvanlissa.github.io/tidySEM/articles/Plotting_graphs.html
install.packages("tidySEM")
library(tidySEM)

tidySEM::graph_sem(model = m1a_fit)

tabla_mediacion <- table_results(m1a_fit,
              columns = c("est_sig", "se", "est_sig_std", "se_std", "pval", "confint"),
              digits = 3)


write_csv(tabla_mediacion, "salidas/tabla_mediacion.csv")

# Algunos tama�os del efecto

# varianza explicada en Y por el efecto indirecto

R2_med = r^2(MY) - (R^2Y.MY - r^2XY)

# par�metros a usar 
#rMY
cor.test(data$Commit, data$Phys_Inf)

#rXY
cor.test(data$LnPorn, data$Phys_Inf)

#R^2
summary(lm(Phys_Inf ~ Commit + LnPorn, data = data))

summary(m1a_fit, rsquare = TRUE)

# computarlo
R2_med = (-.306)^2 - (.114 - (.186^2))

R2_med  # Varianza de Y compartido con el predictor y el mediador (juntos), que no puede 
        # atribuirse a cada uno de ellos por separado.NOTA: tiene limitaciones

# interpretaci�n final

summary(m1a_fit, 
        rsquare = TRUE,
        ci = TRUE, 
        standardized = TRUE)

#--------------------------------------------------------------------------------#
#### 2.2 Mediaci�n paralela ####
#--------------------------------------------------------------------------------#
library(psych)

data2 <-  Tal_Or # datos disponibles en el paquete PSYCH

names(data2)

dim(data2)

glimpse(data2)

# Effect of 'Presumed Media Influence' (pmi) on the intention to act (reaction)
# based upon the importance of a message (import).

set.seed(210208)

# Mediaci�n simple
m2 <- mediate(reaction ~ cond + (pmi), data = data2)

summary(m2, digits = 3)

print(m2, short = FALSE)

# Mediaci�n m�ltiple (paralela) (PSYCH)

m2a <- mediate(reaction ~ cond + (import) + (pmi) , data = data2)

summary(m2a, digits = 3)

print(m2a, digits= 3)

# Mediaci�n m�ltiple (paralela) en lavaan

m2b <- '
        import    ~ a1*cond
        pmi       ~ a2*cond
        reaction  ~ b1*import + b2*pmi + c*cond
        
        # Efectos indirectos
        ind1 := a1*b1
        ind2 := a2*b2
        total_ind := ind1 + ind2
        Total := c + total_ind
        '
m2b_fit <- sem(m2b,
               se = "bootstrap",
               bootstrap = 100,
               data = data2)

summary(m2b_fit, standardized = FALSE)

m2c_fit <- sem(m2b,
               estimator = "MLR",
               data = data2)


summary(m2c_fit, standardized = TRUE, ci = TRUE)

parameterestimates(m2b_fit,
                   boot.ci.type = "perc")

semPaths(m2b_fit, layout = "tree2", "std")

#### 2.3 Mediaci�n serial ####

data3 <- read_csv("data/data_1_4_medserial.csv")

# Lavaan

m3a <- '
proc_polgr ~ a1*cont_pol_pr + ses_renda +  sexor + racar
conf_pol ~ b1*proc_polgr + a2*cont_pol_pr + ses_renda +  sexor + racar
coop_pol ~ c1*conf_pol + b2*proc_polgr + e*cont_pol_pr + ses_renda +  sexor + racar

# ROBUST CHECKS 
#coop_pol_lik ~ c1*conf_pol + b2*proc_polgr + e*cont_pol_pr + ses_renda +  sexor + racar

#indirect effects
ind1 := a1*b1*c1
ind2 := a1*b2
ind3 := a2*c1
ind4 := b1*c1
ind5 := a1*b1

ind_total :=  ind1 + ind2 + ind3 +  ind4 + ind5
total := e + ind_total
'

m3a_fit <- sem(m3a, data=data3)

summary(m3a_fit, standardized=TRUE, rsquare = TRUE)

semPaths(m3a_fit, whatLabels = "std", layout = "tree2")

# pero la variable de confianza es ordinal, entonces habr�a que tener en cuenta esa correcci�n

m3b_fit <- sem(m3a, data=data3, 
               ordered=c("conf_pol"))

summary(m3b_fit, standardized=TRUE, rsquare = TRUE)

#### EJERCICIOS ####

# 1.  Realizar una mediaci�n simple usando los datos de Hayes (pmi), en el cual se eval�e el siguiente efecto indirecto
# import    ->    pmi    ->    reaction (Si van a usar PROCESS, revisar modelos disponibles en el ap�ndice del libro)

pmi <- rio::import("data/pmi.csv")

glimpse(pmi)

psych::pairs.panels(pmi[,c("import", "pmi", "reaction")])

mediacion_ej <- psych::mediate(reaction ~ import + (pmi), 
                               data = pmi)

summary(mediacion_ej)
# 3. Realizar una mediaci�n serial entre cond->import    ->    pmi    ->    reaction

mediacion_ser <- 'import ~ a*cond
                  pmi ~ b*import
                  reaction ~ c*pmi
                  
                  # efecto indirecto
                  ind := a*b*c
                  '
mediacion_ser_fit <- sem(mediacion_ser, 
                         data = pmi)

summary(
  mediacion_ser_fit,
  standardized = TRUE,
  ci = TRUE,
  rsquare = TRUE
  )

# usando process (recuerda cargar la funci�n de process desde el script process.R)

process(
  data = pmi,
  y = "reaction",
  x = "cond",
  m = c("pmi", "import"),
  total = 1,
  contrast = 1,
  model = 6, # Modelo que se va a estimar
  decimals = 9.3, # para tres decimales
  modelbt = 1, # para tener bootstrapped CI
  boot=5000 
)
